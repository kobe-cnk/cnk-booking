const { ApiError, Client, Environment } = require('square');
const { randomUUID } = require('crypto');

const client = new Client({
  accessToken: process.env.SQUARE_ACCESS_TOKEN,
  environment: Environment.Production,
});

exports.handler = async function(event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json'
  };

  try {
    const { nonce, amount, currency, description, email, name, bookingId } = JSON.parse(event.body);

    if (!nonce || !amount || amount < 50) {
      return { statusCode: 400, headers, body: JSON.stringify({ error: 'Missing required fields' }) };
    }

    const { result } = await client.paymentsApi.createPayment({
      sourceId: nonce,
      idempotencyKey: randomUUID(),
      amountMoney: {
        amount: BigInt(Math.round(amount)),
        currency: currency || 'USD',
      },
      note: description,
      buyerEmailAddress: email,
      referenceId: bookingId,
    });

    const payment = result.payment;
    const card = payment.cardDetails?.card;

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        paymentId: payment.id,
        amount: Number(payment.amountMoney.amount),
        cardBrand: card?.cardBrand || '',
        cardLast4: card?.last4 || '',
      })
    };

  } catch (err) {
    console.error('Square payment error:', err);
    const msg = err instanceof ApiError
      ? err.errors?.[0]?.detail || 'Payment failed'
      : err.message || 'Payment failed';
    return { statusCode: 400, headers, body: JSON.stringify({ error: msg }) };
  }
};
