# CNK Booths Booking System — Square Payments

## Step 1 — Add your Square credentials to the HTML file
Open `public/index.html` and find these two lines near the top of the script section:

  const SQUARE_APP_ID   = 'YOUR_SQUARE_APPLICATION_ID';
  const SQUARE_LOCATION = 'YOUR_SQUARE_LOCATION_ID';

Replace with your actual values from developer.squareup.com

## Step 2 — Push to GitHub
1. Create a free account at github.com
2. Create a new repo called `cnk-booking`
3. Upload all these files

## Step 3 — Deploy on Vercel (free, no deploy limits)
1. Go to vercel.com → New Project → Import from GitHub
2. Select `cnk-booking` → Deploy

## Step 4 — Add your Square Access Token
In Vercel dashboard → Settings → Environment Variables:
  SQUARE_ACCESS_TOKEN = your production access token (EAAA...)

Click Redeploy — done!

Every booking will automatically charge the deposit to your Square account.
